import { GoogleGenAI } from "@google/genai";

export const generateEbookCover = async (apiKey: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: "A photorealistic 3D ebook standing upright. The cover has a clean white background. Title text 'STUDY GUIDE' in a classic serif font. Subtitle 'A Guide on How to Control Diabetes Using Nigerian Foods'. In the center, a rectangular photo of hands holding a blue glucose meter checking blood sugar. Author name 'OLUWOLE GEORGE AYODELE' at the bottom. Professional, medical, clean aesthetic.",
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Error generating ebook cover:", error);
    throw error;
  }
};

export const generateFoodImage = async (apiKey: string, prompt: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Error generating food image:", error);
    throw error;
  }
};