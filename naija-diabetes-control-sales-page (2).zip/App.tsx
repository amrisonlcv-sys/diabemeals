import React, { useState, useEffect } from 'react';
import { EbookMockup } from './components/EbookMockup';
import { ApiKeyModal } from './components/ApiKeyModal';
import { generateEbookCover, generateFoodImage } from './services/geminiService';
import { Testimonial } from './types';

// Placeholder Assets
// IMPORTANT: Replace the URL below with the direct link to your uploaded ebook cover image.
// The current placeholder mimics the text of your actual cover.
const PLACEHOLDER_COVER = "https://placehold.co/600x900/FFFFFF/222222/png?text=STUDY+GUIDE%0AControl+Diabetes+Using%0ANigerian+Foods%0A%0ABy+Oluwole+George+Ayodele&font=merriweather";
const PLACEHOLDER_FOOD_1 = "https://picsum.photos/seed/nfood1/800/600";
const PLACEHOLDER_FOOD_2 = "https://picsum.photos/seed/nfood2/800/600";
const PLACEHOLDER_VIDEO_THUMB = "https://picsum.photos/seed/video1/600/400";

const TESTIMONIALS: Testimonial[] = [
  {
    name: "Chidinma Okoro",
    role: "Mother & Business Owner",
    content: "I was skeptical because I love my starch. But this book showed me how to prepare Unripe Plantain Amala in a way that actually lowered my husband's sugar levels within 2 weeks. It's a miracle.",
    image: "https://picsum.photos/seed/person1/100/100"
  },
  {
    name: "Emeka Balogun",
    role: "Banker",
    content: "My doctor was shocked. I went from Hba1c 9.5 to 6.2 in 3 months just by switching my soup recipes to the ones in Chapter 4. Best N5,000 I ever spent.",
    image: "https://picsum.photos/seed/person2/100/100"
  },
  {
    name: "Mrs. Adebayo",
    role: "Retired Teacher",
    content: "Finally, a guide that understands WE ARE NIGERIANS. I don't want to eat salads every day. I want my Swallow. This book taught me how to eat Swallow without spiking my sugar.",
    image: "https://picsum.photos/seed/person3/100/100"
  }
];

export default function App() {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [showApiModal, setShowApiModal] = useState(false);
  
  // Image States
  const [coverUrl, setCoverUrl] = useState(PLACEHOLDER_COVER);
  const [food1Url, setFood1Url] = useState(PLACEHOLDER_FOOD_1);
  const [food2Url, setFood2Url] = useState(PLACEHOLDER_FOOD_2);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    // Check if user wants to use AI features on load (optional implementation detail, usually we prompt)
    const storedKey = localStorage.getItem('gemini_api_key');
    if (storedKey) {
      setApiKey(storedKey);
    } else {
      // Show modal after a brief delay if no key found to offer enhancement
      const timer = setTimeout(() => setShowApiModal(true), 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    const generateImages = async () => {
      if (!apiKey) return;
      setIsGenerating(true);
      try {
        const cover = await generateEbookCover(apiKey);
        setCoverUrl(cover);
        
        const f1 = await generateFoodImage(apiKey, "A delicious bowl of Nigerian Edikang Ikong soup with healthy vegetables and fish, photorealistic, cinematic lighting");
        setFood1Url(f1);

        const f2 = await generateFoodImage(apiKey, "Fresh unripe plantain flour meal with vegetable soup, authentic Nigerian cuisine, high resolution");
        setFood2Url(f2);
      } catch (err) {
        console.error("Failed to generate AI images, reverting to placeholders", err);
      } finally {
        setIsGenerating(false);
      }
    };

    // Only auto-generate if we are still using the placeholder
    if (apiKey && coverUrl === PLACEHOLDER_COVER) {
      generateImages();
    }
  }, [apiKey, coverUrl]);

  const handleApiKeySave = (key: string) => {
    setApiKey(key);
    localStorage.setItem('gemini_api_key', key);
    setShowApiModal(false);
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-gray-800 font-sans selection:bg-green-200">
      {showApiModal && !apiKey && (
        <ApiKeyModal onSave={handleApiKeySave} onClose={() => setShowApiModal(false)} />
      )}

      {/* --- Sticky Header --- */}
      <nav className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="font-serif font-bold text-green-800 text-lg md:text-xl">
            Naija Health Secrets
          </div>
          <a href="#buy-now" className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-full text-sm transition shadow-md">
            Get The Ebook Now
          </a>
        </div>
      </nav>

      {/* --- Hero Section --- */}
      <header className="relative bg-green-900 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="container mx-auto px-4 py-12 md:py-20 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-block bg-orange-500 text-white px-3 py-1 rounded-full text-xs md:text-sm font-bold tracking-wide mb-6 uppercase">
              Attention: Nigerians struggling with High Blood Sugar
            </div>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-black leading-tight mb-6 font-serif">
              Discover How To <span className="text-orange-400">Control Diabetes</span> Using The Nigerian Foods You Already Love
            </h1>
            <p className="text-lg md:text-xl text-green-100 mb-8 max-w-2xl mx-auto leading-relaxed">
              Stop starving yourself with "Oyibo" diets that don't work. Learn the ancient nutritional secrets hidden in our local markets that can stabilize your blood sugar naturally.
            </p>
            
            <div className="flex flex-col md:flex-row justify-center items-center gap-4">
              <a href="#buy-now" className="w-full md:w-auto bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-8 rounded-lg shadow-lg text-lg transition transform hover:scale-105">
                Yes! I Want To Control My Sugar
              </a>
              <p className="text-sm text-green-200 mt-2 md:mt-0 md:ml-4">
                <span className="inline-block w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                1,240+ Copies Sold this month
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* --- VSL & Intro Section --- */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="aspect-w-16 aspect-h-9 bg-gray-900 rounded-xl overflow-hidden shadow-2xl mb-12 relative group">
              {/* Fake Video Player UI */}
              <img src={PLACEHOLDER_VIDEO_THUMB} alt="Video Thumbnail" className="w-full h-full object-cover opacity-60" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 bg-orange-600 rounded-full flex items-center justify-center pl-2 shadow-xl cursor-pointer hover:bg-orange-500 transition group-hover:scale-110">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" /></svg>
                </div>
              </div>
              <p className="absolute bottom-4 left-4 text-white font-bold bg-black/50 px-3 py-1 rounded">Watch: The "Bitter" Truth About Insulin</p>
            </div>

            <div className="prose prose-lg md:prose-xl text-gray-700 mx-auto">
              <p className="font-bold text-2xl mb-6">Dear Friend,</p>
              <p>
                If you are tired of pricking your finger every morning only to see numbers that scare you... if you are tired of doctors telling you to "stop eating eba" or "avoid yam" without giving you any real alternatives... <strong>then this is the most important message you will ever read.</strong>
              </p>
              <p>
                My name is Dr. Emeka (Nutritionist), and I have spent the last 10 years studying the effects of African indigenous crops on metabolic health.
              </p>
              <p>
                Here is the shocking truth: <strong>You do not need to eat expensive imported salads to control your diabetes.</strong>
              </p>
              <p>
                In fact, some of the most potent blood-sugar lowering compounds on earth are found right here in Nigeria, in the local markets of Lagos, Kano, Enugu, and Port Harcourt.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* --- Mockup Appearance 1 --- */}
      <section className="py-12 bg-green-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-serif font-bold text-green-900 mb-8">The Solution You've Been Waiting For</h2>
          <EbookMockup imageUrl={coverUrl} className="max-w-md mx-auto" />
        </div>
      </section>

      {/* --- The Problem Section --- */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900 mb-8 text-center">
              Why "Standard Advice" Is Failing Nigerians
            </h2>
            <div className="grid md:grid-cols-2 gap-8 items-center mb-8">
               <img src={food1Url} alt="Nigerian Food" className="rounded-lg shadow-lg w-full h-64 object-cover" />
               <div className="prose prose-lg text-gray-700">
                 <p>
                   Most diet advice is copied from Western textbooks. They tell you to eat broccoli, kale, and quinoa.
                 </p>
                 <p>
                   <strong>But let's be honest.</strong> Can you sustain that in Nigeria? Can you afford it? Does it satisfy your soul?
                 </p>
                 <p>
                   When you force yourself to eat strange foods, you inevitably crash. You go back to pounding fufu because you are hungry and miserable. And the sugar spikes return with a vengeance.
                 </p>
               </div>
            </div>
            <p className="text-xl font-bold text-red-600 text-center bg-red-50 p-6 rounded-lg border border-red-200">
              The cycle of "Starve -> Crave -> Binge -> Spike" is what destroys your kidneys, your eyes, and your nerves.
            </p>
          </div>
        </div>
      </section>

      {/* --- Mockup Appearance 2 --- */}
      <section className="py-8">
        <div className="container mx-auto px-4 flex justify-center">
           <EbookMockup imageUrl={coverUrl} className="max-w-sm" />
        </div>
      </section>

      {/* --- The Solution / Benefits --- */}
      <section className="py-16 bg-green-900 text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-center mb-12 text-orange-400">
            Enter The "Nigerian Diet Protocol"
          </h2>
          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-orange-500 rounded-full p-2 mt-1 mr-4 shrink-0">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Eat "Swallow" Without Fear</h3>
                  <p className="text-green-200">Discover the specific flours (like unripe plantain and guinea corn) and the EXACT preparation method that reduces their glycemic index by 40%.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-orange-500 rounded-full p-2 mt-1 mr-4 shrink-0">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">The "Bitter" Secret</h3>
                  <p className="text-green-200">How to use Bitter Leaf (Vernonia amygdalina) not just for soup, but as a potent medicinal tea that mimics the effect of Metformin naturally.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-orange-500 rounded-full p-2 mt-1 mr-4 shrink-0">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Local Superfoods</h3>
                  <p className="text-green-200">A detailed list of 25 Nigerian ingredients (like Ukwa, Garden Egg, and Acha) that actively repair insulin sensitivity.</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <img src={food2Url} alt="Healthy Nigerian Dish" className="rounded-xl shadow-2xl border-4 border-orange-500/50" />
              <div className="absolute -bottom-6 -right-6 bg-white text-green-900 p-4 rounded-lg shadow-xl font-bold max-w-xs">
                "I never knew I could eat pounded yam this way and still have stable sugar!"
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- Mockup Appearance 3 (Mid-Page) --- */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4 flex flex-col items-center">
          <h2 className="text-2xl font-bold mb-6 text-gray-800">Get The Full Protocol Now</h2>
           <EbookMockup imageUrl={coverUrl} className="max-w-md transform rotate-1 hover:rotate-0 transition duration-500" />
        </div>
      </section>

      {/* --- Testimonials --- */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-serif font-bold text-center mb-12 text-green-900">
            What Nigerians Are Saying
          </h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {TESTIMONIALS.map((t, idx) => (
              <div key={idx} className="bg-gray-50 p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition">
                <div className="flex items-center mb-4">
                  <img src={t.image} alt={t.name} className="w-12 h-12 rounded-full mr-4" />
                  <div>
                    <h4 className="font-bold text-gray-900">{t.name}</h4>
                    <span className="text-sm text-gray-500">{t.role}</span>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-3">
                  {[...Array(5)].map((_, i) => <svg key={i} className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>)}
                </div>
                <p className="text-gray-700 italic">"{t.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Deep Dive Content (SEO/Long Form Logic) --- */}
      <section className="py-16 bg-neutral-100">
         <div className="container mx-auto px-4 max-w-3xl prose prose-lg">
            <h3 className="text-center font-serif text-3xl mb-8">Inside The Book: A Sneak Peek</h3>
            <div className="bg-white p-8 rounded-xl shadow-sm border-l-4 border-green-600">
               <h4 className="text-green-800 font-bold mt-0">Chapter 1: The "Sugar Reset" Detox</h4>
               <p>How to flush out the toxins clogging your liver using a simple concoction of cucumber and a specific local leaf found in every market.</p>
               
               <h4 className="text-green-800 font-bold">Chapter 3: The King of Soups</h4>
               <p>Why Ogbono soup (when cooked without ONE common ingredient) is a superfood for diabetics, and how to make it delicious.</p>
               
               <h4 className="text-green-800 font-bold">Chapter 7: The 7-Day Meal Plan</h4>
               <p>A complete done-for-you timetable. Breakfast, Lunch, and Dinner. No thinking required. Just cook, eat, and watch your numbers drop.</p>
            </div>
         </div>
      </section>

      {/* --- Mockup Appearance 4 --- */}
      <section className="py-8 bg-neutral-100">
        <div className="container mx-auto px-4 flex justify-center">
           <EbookMockup imageUrl={coverUrl} className="max-w-sm" />
        </div>
      </section>

      {/* --- Guarantee Section --- */}
      <section className="py-16 bg-white border-y border-gray-200">
        <div className="container mx-auto px-4 text-center max-w-2xl">
          <div className="inline-block p-4 rounded-full bg-green-100 mb-6">
            <svg className="w-16 h-16 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
          </div>
          <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">60-Day Ironclad Money-Back Guarantee</h2>
          <p className="text-gray-600 text-lg mb-8">
            Buy the book. Try the recipes for a full 60 days. If you don't feel more energetic, if your numbers don't improve, or if you simply don't like the font size... send me an email and I will refund every Naira. No questions asked.
          </p>
        </div>
      </section>

      {/* --- Mockup Appearance 5 --- */}
      <section className="py-10 bg-green-50">
        <div className="container mx-auto px-4 flex justify-center">
           <EbookMockup imageUrl={coverUrl} className="max-w-sm" />
        </div>
      </section>

      {/* --- FAQ Section --- */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="text-3xl font-bold text-center mb-10 text-gray-900">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              { q: "Is this a physical book?", a: "No, this is a digital ebook (PDF). You will receive the download link immediately after payment so you can start reading on your phone or laptop instantly." },
              { q: "Can I still eat rice?", a: "Yes! But you must cook it the way I describe in Chapter 5 to remove the excess starch. I show you exactly how." },
              { q: "I am not good at cooking. Is this hard?", a: "Not at all. The recipes are standard Nigerian meals you already know—just with small, critical adjustments." },
              { q: "How do I pay?", a: "We use Selar, which is 100% secure. You can pay via Bank Transfer, USSD, or Card." }
            ].map((faq, i) => (
              <div key={i} className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-bold text-lg text-gray-900 mb-2">{faq.q}</h4>
                <p className="text-gray-600">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Final CTA Section (Mockup Appearance 6) --- */}
      <section id="buy-now" className="py-20 bg-green-900 text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-serif font-black mb-6">Take Control of Your Health Today</h2>
          <p className="text-xl text-green-200 mb-10 max-w-2xl mx-auto">
            Don't let diabetes dictate your life for one more day. The solution is in your hands (and in your kitchen).
          </p>
          <div className="flex justify-center mb-12">
             <EbookMockup imageUrl={coverUrl} className="max-w-md bg-white/10 backdrop-blur-none border-green-700" />
          </div>
          <div className="text-sm text-green-300 opacity-70">
            DISCLAIMER: This book provides nutritional information and is not a substitute for professional medical advice. Always consult your doctor before making major changes to your diet or medication.
          </div>
        </div>
      </section>

      {/* --- Footer --- */}
      <footer className="bg-gray-900 text-gray-400 py-12 border-t border-gray-800">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">&copy; {new Date().getFullYear()} Naija Health Secrets. All rights reserved.</p>
          <div className="flex justify-center space-x-6 text-sm">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
            <a href="#" className="hover:text-white">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}